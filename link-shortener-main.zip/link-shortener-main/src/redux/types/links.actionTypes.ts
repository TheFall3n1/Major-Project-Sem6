export const SET_LOADING = 'SET_LOADING';
export const SET_LINKS = 'SET_LINKS';
